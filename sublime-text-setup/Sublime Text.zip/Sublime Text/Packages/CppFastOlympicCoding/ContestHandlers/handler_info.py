from . import codeforces

handlers = [codeforces]