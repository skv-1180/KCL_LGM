#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 1e9+7;
const int INF=1e18+10;
#define colon ;
#define endl '\n'
#define ff first
#define ss second
#define pb push_back
#define vi vector<int>
#define pii pair<int,int>
#define cint(x) int x colon cin>>x;
#define cstr(x) string x colon cin>>x;
#define ssort(v) sort(begin(v),end(v)); 
#define rev(v) reverse(begin(v),end(v));
#define ccint(x,y) int x,y colon cin>>x>>y;
#define ccstr(x,y) string x,y colon cin>>x>>y;
#define print(v) for(auto x:v)cout<<x<<' ';cout<<endl;
#define cvect(v,n) vector<int>v(n)colon for(int i=0;i<n;i++)cin>>v[i];

#ifndef ONLINE_JUDGE
#include<bits/debugger.h>
#else
#define cl()
#define setio
#define graph(x,y)
#define debug(x...)
#define debugptr(x,y)
#endif

signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);//setio 
    #ifndef ONLINE_JUDGE
        freopen("debug.t","w",stderr);
    #endif
    
    int t=1,TestCase=0;cin>>t;
    while(t--){
        TestCase++;debug(TestCase)
            cint(n)
            cvect(v,n)
            int ate=0;int cnt=0;
            for(int i=0;i<n;i++){
                if(v[i]%2==0){
                    ate++;
                }else{
                    cnt++;
                }
            }
            if(cnt >= 2 && cnt%2==0){
                cout<<"yes"<<endl;
            }else if(cnt == 0){
                cout<<"yes"<<endl;
            }else{
                cout<<"no"<<endl;
            }
        cl()
    }
return 0;
}